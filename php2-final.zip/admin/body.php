<div class='container'>
    <h1>Trang quản trị</h1>
</div>