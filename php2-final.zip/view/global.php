<?php
    $linkimg="upload/";
?>